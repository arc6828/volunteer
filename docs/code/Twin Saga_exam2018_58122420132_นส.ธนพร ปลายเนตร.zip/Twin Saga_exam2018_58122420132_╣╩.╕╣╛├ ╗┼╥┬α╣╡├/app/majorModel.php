<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class majorModel extends Model
{
    function select(){
		$sql = "select * from major";
		return DB::select($sql, []);
	}

	function select_id($id){
		$sql = "select * from  major where id = {$id}";
		return DB::select($sql, []);
	}

	function select_search($q){
		$sql = "select * from  major where name like '%{$q}%'";
		return DB::select($sql, []);
	}

	function insert($name, $category, $price, $quantity){
		$sql = "insert into  major (major_name,id_faculty,id_major_auto) 
				values ( '{$id_major_auto}', '{$major_name}', {$id_faculty})";
		DB::insert($sql, []);
	}

	function update($major_name,$id_faculty,$id_major_auto){
		$sql = "update  major set 
				id_major_auto = '{$id_major_auto}',
				major_name = '{$major_name}',  
				id_faculty =  {$id_faculty};
		DB::update($sql, []);
	}

	function delete($major_name,$id_faculty,$id_major_auto){
		$sql = "delete from major where id = {$id}";
		DB::delete($sql, []);
	}

}

}
