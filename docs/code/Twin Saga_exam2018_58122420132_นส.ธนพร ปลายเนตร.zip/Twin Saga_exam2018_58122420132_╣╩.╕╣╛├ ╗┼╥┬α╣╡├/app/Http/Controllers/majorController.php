<?php

namespace App\Http\Controllers;

use App\majorModel;
use Illuminate\Http\Request;

class majorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $model = new majorModel();
        /*$table_food = $model->select();*/
        /*$data = ['table_food' => $table_customer];*/
       $q = $request->input('q');
        $table_major = $model->select_search($q);

        $data = [
            'table_major' => $table_major,
            'q' => $q
        ];
        return view('major/index',$data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('major/create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $major_name = $request->input('major_name');
        $id_major_auto = $request->input('id_major_auto');
        $id_faculty = $request->input('id_faculty');

        $model = new majorModel();
        $model->insert($major_name,$id_faculty,$id_major_auto);

        return redirect('/major');

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\foodModel  $foodModel
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $model = new majorModel();
        $table_major = $model->select_id($id);
        $data = [
            'table_major' => $table_major
        ];
        return view('major/show',$data);

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\foodModel  $foodModel
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $model = new majorModel();
        $table_major = $model->select_id($id);
        $data = [
            'table_major' => $table_major
        ];
        return view('major/edit',$data);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\foodModel  $foodModel
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $major_name = $request->input('major_name');
        $id_major_auto = $request->input('id_major_auto');
        $id_faculty = $request->input('id_faculty');
        
        $model = new majorModel();
        $model-> update($major_name,$id_faculty,$id_major_auto);

        return redirect('/major');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\foodModel  $foodModel
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $model = new majorModel();
        $model->delete($id);

        return redirect('/major');
    }
    public function __construct()
{
    $this->middleware('auth');    
    $this->middleware('role:admin_dsd') ;
}

}
