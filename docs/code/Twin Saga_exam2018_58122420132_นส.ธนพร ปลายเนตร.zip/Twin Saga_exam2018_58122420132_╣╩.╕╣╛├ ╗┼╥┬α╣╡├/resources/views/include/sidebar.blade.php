@section('sidebar')
<h2>Section Sidebar in content</h2>
<div>
ในอนาคตพื้นที่ส่วนนี้จะถูกใช้เป็น Sidebar
</div>
@endsection
