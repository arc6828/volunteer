@extends('layout/template-pricing')
<link href="{{ url('/') }}/style.css" rel="stylesheet" type="text/css">
@section('content')

@forelse($table_food as $row)
	<h1>major: {{ $row->id }} </h1>
	<div class="line">
		<strong>id_major_auto : </strong>
		<span>{{ $row->id_major_auto }} </span>
	</div>
	<div class="line">
		<strong>major_name : </strong>
		<span>{{ $row->major_name }}</span>
	</div>
	<div class="line">
		<strong>id_faculty : </strong>		
		<span>{{ $row->id_faculty }}</span>
	</div><br>
	
@empty
	<div>This major id does not exist</div>
@endforelse
<style>
button.button-2{
	color : #fff;					
	background-color : #17a2b8;
	border : 1px solid #007bff;		
	border-radius : 5px;			
	margin-right : 10px;	
	padding : 10px;		
}
</style>
<button class="button-2"> Black to all tasks </button>

<style>
button.button-2{
	color : #fff;					
	background-color : #007bff;
	border : 1px solid #007bff;		
	border-radius : 5px;			
	margin-right : 10px;	
	padding : 10px;		
}
</style>
<form class="inline" action="{{ url('/') }}/major/{{ $row->id }}" method="POST">
		{{ csrf_field() }}
		{{ method_field('DELETE') }}
		<button type="submit">Delete</button>
	</form>
<button class="button-2"> Update Task </button>

</div>
@endsection
