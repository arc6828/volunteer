@extends('layout/template-pricing')
<link href="{{ url('/') }}/style.css" rel="stylesheet" type="text/css">
@section('content')

@forelse($table_major as $row)
<h1>Edit major : {{ $row->id }}</h1>
	<form action="{{ url('/') }}/major/{{ $row->id }}" method="POST">
		{{ csrf_field() }}
		{{ method_field('PUT') }}
		
		<div class="line">
			<strong>id_major_auto: </strong>
			<input type="number" name="id_major_auto" value="{{ $row->id_major_auto}}" >
		</div>
		<div class="line">
			<strong>major_name: </strong>
			<input type="text" name="major_name" value="{{ $row->major_name}}"  >
		</div>
		<div class="line">
			<strong>id_faculty: </strong>
			<input type="number" name="id_faculty" value="{{ $row->id_faculty}}" >
		</div>
		<style>
button.button-2{
	color : #fff;					
	background-color : #007bff;
	border : 1px solid #007bff;		
	border-radius : 5px;			
	margin-right : 10px;	
	padding : 10px;		
}
</style>
<button class="button-2"> Black to all tasks </button>

<style>
button.button-2{
	color : #fff;					
	background-color : #007bff;
	border : 1px solid #007bff;		
	border-radius : 5px;			
	margin-right : 10px;	
	padding : 10px;		
}
</style>
<button class="button-2"> update tasks </button>
	</form>
@empty	
	<div>This major id does not exist</div>
@endforelse
@endsection