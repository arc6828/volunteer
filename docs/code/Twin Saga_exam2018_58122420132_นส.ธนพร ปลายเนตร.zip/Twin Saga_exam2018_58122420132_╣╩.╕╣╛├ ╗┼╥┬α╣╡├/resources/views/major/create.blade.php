@extends('layout/template-pricing')
<link href="{{ url('/') }}/style.css" rel="stylesheet" type="text/css">
@section('content')

<h1>Create New major</h1>
<form action="{{ url('/') }}/major" method="POST">
	{{ csrf_field() }}
	{{ method_field('POST') }}
	<div class="line">
		<strong>id_major_auto : </strong>
		<input type="number" name="id_major_auto" placeholder="id_major_auto here..." >
	</div>
	<div class="line">
		<strong>major_name : </strong>
		<input type="text" name="major_name" placeholder="major_name here..." >
	</div>
	<div class="line">
		<strong>id_faculty: </strong>
		<input type="number" name="id_faculty" placeholder="id_faculty here..." >
	</div>
</form>

<style>
button.button-2{
	color : #fff;					
	background-color : #007bff;
	border : 1px solid #007bff;		
	border-radius : 5px;			
	margin-right : 10px;	
	padding : 10px;		
}
</style>
<button class="button-2"> Black to all tasks </button>


<style>
button.button-2{
	color : #fff;					
	background-color : #007bff;
	border : 1px solid #007bff;		
	border-radius : 5px;			
	margin-right : 10px;	
	padding : 10px;		
}
</style>
<button class="button-2"> Create Task </button>
@endsection